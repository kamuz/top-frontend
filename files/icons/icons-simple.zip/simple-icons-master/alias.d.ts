import { SimpleIcon } from '.';

/**
 * @internal
 */
export type I = SimpleIcon;
